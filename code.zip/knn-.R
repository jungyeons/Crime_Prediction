crime.data <- read.csv("2020_total_nat.csv", header=T)
crime.data 
options(scipen = 999)
library(dplyr)

library(caret)
#partitioning
set.seed(1)
train.crime.rows <- sample(rownames(crime.data), dim(crime.data)[1]*0.7)
# train.crime.data <- crime.data[train.crime.rows, -12]
train.crime.data <- crime.data %>% select(-"d20_col_code") %>% select(-"d20_col_name") %>% select(-"d20_col_8")
train.crime.data <- train.crime.data[train.crime.rows, ]

valid.crime.rows <- setdiff(rownames(crime.data), train.crime.rows)
# valid.crime.data <- crime.data[valid.crime.rows, -12]
valid.crime.data <- crime.data %>% select(-"d20_col_code") %>% select(-"d20_col_name") %>% select(-"d20_col_8")
valid.crime.data <- valid.crime.data[valid.crime.rows, ]


# normalization
train.norm.crime.data <- train.crime.data
valid.norm.crime.data <- valid.crime.data

crime.norm <- preProcess(train.crime.data, method=c("center", "scale"))

train.norm.crime.data <- as.data.frame(predict(crime.norm, train.crime.data))
valid.norm.crime.data <- as.data.frame(predict(crime.norm, valid.crime.data))

# k값별 정확도 비교
crime.model.accuracy <- data.frame(k = c(1,2,3,4,5), RMSE = c(0,0,0,0,0))
crime.model1 <- class::knn(train = train.norm.crime.data[,-1],                          
                             test = valid.norm.crime.data[,-1],                          
                             cl = train.crime.data[,1], k = crime.model.accuracy[1,1])
crime.model2 <- class::knn(train = train.norm.crime.data[,-1],                          
                             test = valid.norm.crime.data[,-1],                          
                             cl = train.crime.data[,1], k = crime.model.accuracy[2,1])
crime.model3 <- class::knn(train = train.norm.crime.data[,-1],                          
                             test = valid.norm.crime.data[,-1],                          
                             cl = train.crime.data[,1], k = crime.model.accuracy[3,1])
crime.model4 <- class::knn(train = train.norm.crime.data[,-1],                          
                             test = valid.norm.crime.data[,-1],                          
                             cl = train.crime.data[,1], k = crime.model.accuracy[4,1])
crime.model5 <- class::knn(train = train.norm.crime.data[,-1],                          
                             test = valid.norm.crime.data[,-1],                          
                             cl = train.crime.data[,1], k = crime.model.accuracy[5,1])

crime.model.accuracy[1,2] <- RMSE(as.numeric(as.character(crime.model1)),valid.crime.data[,1])
crime.model.accuracy[2,2] <- RMSE(as.numeric(as.character(crime.model2)),valid.crime.data[,1])
crime.model.accuracy[3,2] <- RMSE(as.numeric(as.character(crime.model3)),valid.crime.data[,1])
crime.model.accuracy[4,2] <- RMSE(as.numeric(as.character(crime.model4)),valid.crime.data[,1])
crime.model.accuracy[5,2] <- RMSE(as.numeric(as.character(crime.model5)),valid.crime.data[,1])

crime.model.accuracy

