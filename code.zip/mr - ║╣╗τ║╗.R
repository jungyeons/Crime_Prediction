crimperdistrict.df <- read.csv("2020_total_nat.csv", header=T)
crimperdistrict.des.df <- read.csv("2020_total_nat_description.csv")

library(dplyr)
options(scipen=999)
set.seed(1)
View(crimperdistrict.df)

#필요없는 데이터 분리
crimperdistrict.df <- crimperdistrict.df %>% select(-"d20_col_code") %>% select(-"d20_col_name") %>% select(-"d20_col_8")

#Normalization
norm.crimperdistrict.df <- crimperdistrict.df
library(caret)
#norm.values <- preProcess(crimperdistrict.df[, 3:14], method = c("center", "scale"))
#norm.crimperdistrict.df[, 3:14] <- predict(norm.values, crimperdistrict.df[, 3:14])

norm.values <- preProcess(crimperdistrict.df[, ], method = c("center", "scale"))
norm.crimperdistrict.df[, ] <- predict(norm.values, crimperdistrict.df[, ])

############################################
#partitioning
train.crimperdistrict.rows <- sample(rownames(norm.crimperdistrict.df), dim(norm.crimperdistrict.df)[1]*0.7)
train.crimperdistrict.df <- norm.crimperdistrict.df[train.crimperdistrict.rows, ]
valid.crimperdistrict.rows <- setdiff(rownames(norm.crimperdistrict.df), train.crimperdistrict.rows)
valid.crimperdistrict.df <- norm.crimperdistrict.df[valid.crimperdistrict.rows, ]

#regression modeling
crim.model <- lm(d20_col_1 ~ ., data = train.crimperdistrict.df)
summary(crim.model)

#install.packages("leaps")
library(leaps)
crim.leaps <- regsubsets(d20_col_1 ~ ., data = train.crimperdistrict.df, nbest = 1, nvmax = dim(train.crimperdistrict.df)[2], method = "exhaustive")
summary(crim.leaps)

plot(crim.leaps, scale="adjr2")

###############################################
#model apply(with no var except)
library(forecast)

crim.train.predicted <- predict(crim.model, train.crimperdistrict.df)
crim.valid.predicted <- predict(crim.model, valid.crimperdistrict.df)

crim.train.accuracy <- accuracy(train.crimperdistrict.df$d20_col_1, crim.train.predicted)
crim.valid.accuracy <- accuracy(valid.crimperdistrict.df$d20_col_1, crim.valid.predicted)

###############################################

